import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pgraph',
  templateUrl: './pgraph.component.html',
  styleUrls: ['./pgraph.component.scss']
})
export class PgraphComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
