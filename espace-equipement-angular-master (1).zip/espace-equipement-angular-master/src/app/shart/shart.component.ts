import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-shart',
  templateUrl: './shart.component.html',
  styleUrls: ['./shart.component.scss']
})
export class ShartComponent implements OnInit {

  constructor() { }

  ngOnInit() {


  }

}
