import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-madfilter',
  templateUrl: './madfilter.component.html',
  styleUrls: ['./madfilter.component.scss']
})
export class MadfilterComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
