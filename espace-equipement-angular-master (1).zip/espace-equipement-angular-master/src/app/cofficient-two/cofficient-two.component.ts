import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cofficient-two',
  templateUrl: './cofficient-two.component.html',
  styleUrls: ['./cofficient-two.component.scss']
})
export class CofficientTwoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
