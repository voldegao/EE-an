import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-madp',
  templateUrl: './madp.component.html',
  styleUrls: ['./madp.component.scss']
})
export class MadpComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
