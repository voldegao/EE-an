import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-stockgraph',
  templateUrl: './stockgraph.component.html',
  styleUrls: ['./stockgraph.component.scss']
})
export class StockgraphComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
